define("ace/snippets/rhtml",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "rhtml";

});
